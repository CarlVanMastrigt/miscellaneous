import sys
from pathlib import Path
import subprocess

if(len(sys.argv) < 3):
	sys.exit("usage: src dst [flags]")

script=sys.argv[0]
src_dir=sys.argv[1]
dst_dir=sys.argv[2]
arguments=sys.argv[3:]

src_dir_path=Path(src_dir)
dst_dir_path=Path(dst_dir)

extension_patterns=["*.frag","*.geom","*.vert","*.comp"]

for ext in extension_patterns:
	for src_path in Path(src_dir).rglob(ext):
		abs_fragment = src_path.relative_to(src_dir_path)
		dst_path = dst_dir_path / abs_fragment.with_suffix(abs_fragment.suffix + ".spv")
		dst_path.parents[0].mkdir(parents=True,exist_ok=True)
		if( not dst_path.is_file() or dst_path.stat().st_mtime < src_path.stat().st_mtime):
			print("compile shader: " + str(src_path) + " to " + str(dst_path))
			subprocess.run(["glslc","-c","-o",str(dst_path),str(src_path)]+arguments)