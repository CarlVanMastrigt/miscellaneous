import sys
from pathlib import Path
import subprocess

if(len(sys.argv) < 3):
	sys.exit("usage: src dst [flags]")

script=sys.argv[0]
compiler=sys.argv[1]
src_dir=sys.argv[2]
dst_file=sys.argv[3]

#test for internal arguments

arguments=sys.argv[4:]

src_dir_path=Path(src_dir)

extension_patterns=["*.o"]

# how to make this multithreaded??

command_args =[compiler,"-o",dst_file]

dst_file_path = Path(dst_file)
compile = not dst_file_path.is_file()
if(not compile):
	dst_file_mt = dst_file_path.stat().st_mtime
else:
	# ??
	dst_file_mt = 0

for ext in extension_patterns:
	for src_path in Path(src_dir).rglob(ext):
		if(not compile):
			compile = dst_file_mt < src_path.stat().st_mtime
		command_args.append(str(src_path))
		# print(str(src_path))

command_args += arguments

if compile:
	cmp_out = subprocess.run(command_args, capture_output=True, universal_newlines=True).stderr
	print(cmp_out)