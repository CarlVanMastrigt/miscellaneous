import sublime
import sublime_plugin

import functools

class DuplicateSelectionAndMoveCommand(sublime_plugin.TextCommand):

    def run(self, edit, event=None):
        selection = self.view.substr(self.view.sel()[0])
        # old_region = self.view.sel()[0]
        point = self.view.sel()[0].b if not event else self.view.window_to_text((event["x"], event["y"]))
        # self.view.sel().subtract(old_region)
        self.view.sel().clear()
        num_chars = self.view.insert(edit, point, selection)
        self.view.sel().add(sublime.Region(point,point+num_chars))

    def want_event(self):
        return True

    def is_enabled(self):
        # Disable the command when selection empty or more than 1 selection
        return (
            len(self.view.sel()) == 1 and
            len(self.view.sel()[0]) != 0)
