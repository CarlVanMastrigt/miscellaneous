#!/bin/sh

# echo $1

for file in $1/*
do
    if [ -d $file ];then
        result=$(sh $0 $file)
        echo $result
    else
    	ext="${file##*.}"
        if [ $ext = "o" ];then
            echo $file" "
        fi
    fi
done