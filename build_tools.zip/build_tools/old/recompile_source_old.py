import sys
from pathlib import Path
from subprocess import Popen, PIPE
import re

if(len(sys.argv) < 3):
	sys.exit("usage: src dst [flags]")

script = sys.argv[0]
src_dir = sys.argv[1]
dst_dir = sys.argv[2]

#test for internal arguments

arguments=sys.argv[3:]

src_dir_path = Path(src_dir)
dst_dir_path = Path(dst_dir)

extension_patterns = ["*.c"]

# how to make this multithreaded??

errors = []
dependency_map = {}




def check_for_errors( s ):
	""" isolates line warnings/errors output by a system call and filters errors out from warning so that they can be printed in reverse order at end of execution """
	results = re.findall("(^[^:\n]+):([0-9]+):([0-9]+):(.+)", s, re.M) ## re.M = multiline
	for r in results:
		# print(r[3])
		line = r[0] + ":" + r[1] + ":" + r[2] + ":" + r[3];
		if("error" in r[3]):
			errors.append(line)
		else:
			print(line)


for ext in extension_patterns:
	src_tuples = []
	processes = []
	#could parallelise this more easily by constructing a list while also kicking off dep creation where necessary 
	for src_path in Path(src_dir).rglob(ext):
		src_abs_fragment = src_path.relative_to(src_dir_path)
		dst_path_o = dst_dir_path / src_abs_fragment.with_suffix(".o")
		dst_path_o.parents[0].mkdir(parents=True, exist_ok=True)

		src_mt = src_path.stat().st_mtime

		# compile if dst doesn't exist src has changed since it was compiled 
		compile = not dst_path_o.is_file() or dst_path_o.stat().st_mtime < src_mt

		dst_path_d = dst_dir_path / src_abs_fragment.with_suffix(".d")
		# if o-file parent directories exist, so must d-file's

		# create the dependency list file if src has changed or dep doesnt exist
		if( compile or not dst_path_d.is_file() or dst_path_d.stat().st_mtime < src_mt ):
			# print("create dep file")
			processes.append(Popen(["gcc", str(src_path), "-MM", "-MF", str(dst_path_d)] + arguments, universal_newlines=True, stdout=PIPE, stderr=PIPE))
			# check_for_errors(dep_out)

		src_tuples.append((src_path, compile, dst_path_d, dst_path_o))


	while len(processes) > 0 :
		print("wait on dependencies")
		living_processes = []
		for p in processes:
			stdout, stderr = p.communicate()
			check_for_errors(stderr)
			if(p.poll() == None):
				living_processes.append(p)
		processes = living_processes

	for src_path, compile, dst_path_d, dst_path_o in src_tuples:

		# analyse deps, checking against map, need to do this even if compiling to record that we looked at these files (marked them)
		if(not compile):
			dependencies = dst_path_d.read_text()
			local_dep_files = re.findall(src_dir+"/([^ ]*?).h ", dependencies, re.M) ## re.M = multiline
			for ld_fragment in local_dep_files:
				src_dep = src_dir_path / (ld_fragment + ".h")

				# ld_fragment is key in map
				if ld_fragment in dependency_map:
					dep_mt = dependency_map[ld_fragment]
					# print("dep changed: " + str(dep_changed))
				else:
					if(not src_dep.is_file()):
						sys.exit("error:0:0:error dependency missing")
					dep_mt = src_dep.stat().st_mtime
					dependency_map[ld_fragment] = dep_mt
					# print("check mark file: " + str(dep_changed))

				# if we're here (analysing dependencies) the o file must exist and we must have found its mod time
				compile = compile or dst_path_o.stat().st_mtime < dep_mt

		if( compile ):
			processes.append(Popen(["gcc", str(src_path), "-o", str(dst_path_o), "-c"] + arguments, universal_newlines=True, stdout=PIPE, stderr=PIPE))
			# print("compile")
			# cmp_out = subprocess.run(["gcc", str(src_path), "-o", str(dst_path_o), "-c"] + arguments, capture_output=True, universal_newlines=True).stderr
			# check_for_errors(cmp_out)

	while len(processes) > 0 :
		print("wait on compilation")
		living_processes = []
		for p in processes:
			stdout, stderr = p.communicate()
			check_for_errors(stderr)
			if(p.poll() == None):
				living_processes.append(p)
		processes = living_processes

for line in reversed(errors):
	print(line)