#!/bin/sh

program_name=$2
shell_dir="${0%/*}"
all_objects=$(sh $shell_dir/find_all_objects.sh $1)

shift 2

# echo $@
# echo $all_objects
gcc -o $program_name $all_objects $@
# echo "gcc -o" $1 $all_objects $@