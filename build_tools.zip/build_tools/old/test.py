import re

cmp_out="a  \nsource/cvm_shared/cvm_vk.h:297:2: warning: #warning probably better to split this, create struct and return/result type [-Wcpp]\n297 | #warning probably better to split this, create struct and return/result type\n |  ^~~~~~~"

results = re.findall("(^[^:\n]+):([0-9]*):([0-9]*):(.*)", cmp_out, re.M)
for r in results:
	# print(r[3])
	print("---")
	print(r[0] + ":" + r[1] + ":" + r[2] + ":" + r[3])