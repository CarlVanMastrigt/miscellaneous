#!/bin/sh

#how can this be made multithreaded??

script=$0
src_dir=$1
dst_dir=$2

shift 2

#this doesnt respect dependencies, might be easier to do analysis in python

#make sure src_dir exists and is a dir
if [ ! -d $src_dir ] ;then
    echo "ERROR:" $src_dir "is not a directory"
fi
if [ ! -d $dst_dir ]; then
    echo "making dst directory"
    mkdir $dst_dir
fi


for src_entry in $src_dir/*
do
    #match after last / # would match after first /
    dst_entry=$dst_dir/"${src_entry##*/}"

    if [ -d $src_entry ] ;then
        if [ ! -d $dst_entry ] ;then
            echo "make directory" $dst_entry
            mkdir $dst_entry
        fi
        sh $script $src_entry $dst_entry $@
    else
        # match after last .
        ext="${src_entry##*.}"
        if [ "$ext" = "c" ]; then
            dst_entry="${dst_entry%.*}".o
            echo $dst_entry
            if [ ! -e $dst_entry ] || [ $dst_entry -ot $src_entry ]; then
                echo "compiling" $c_file "into" $o_file
                gcc $src_entry -o $dst_entry -c $@
            fi
        fi
    fi
done


# wallet=$(mktemp -p /dev/shm/)
# above is best option i think for future tmp file for shader variants

#tempfile=$mktemp #use this as part of creating shader variants?
# mount -t tmpfs -o size=500m tmpfs /mountpoint
# command | tee /mountpoint/scriptnameYYYYMMDD.txt

# or $mktemp --tmpdir
#https://unix.stackexchange.com/questions/188536/how-to-make-a-temporary-file-in-ram