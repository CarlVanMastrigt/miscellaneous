import sys
from pathlib import Path
from subprocess import Popen, PIPE
import re

if(len(sys.argv) < 4):
	sys.exit("usage: compiler src dst [flags]")

script = sys.argv[0]
compiler = sys.argv[1]
# ^ gcc or clang
src_dir = sys.argv[2]
dst_dir = sys.argv[3]

#test for internal arguments

arguments = sys.argv[4:]

src_dir_path = Path(src_dir)
dst_dir_path = Path(dst_dir)

#extension_patterns = ["*.c"]

# how to make this multithreaded??

errors = []
warnings_and_misc = []
dependency_map = {}

max_threads = 1


def check_for_errors( s ):
	""" isolates line warnings/errors output by a system call and filters errors out from warning so that they can be printed in reverse order at end of execution """
	results = re.findall("(^[^:\n]+):([0-9]+):([0-9]+):(.+)", s, re.M) ## re.M = multiline
	for r in results:
		# print(r[3])
		line = r[0] + ":" + r[1] + ":" + r[2] + ":" + r[3];
		if(" error: " in r[3]):
			errors.append(line)
		else:
			warnings_and_misc.append(line)


def flush_process_queue( processes , flush_target ):
	while len(processes) > flush_target:
		stdout, stderr = processes[0].communicate()
		check_for_errors(stderr)
		if stdout:
			print(stdout)
		processes.pop(0)


out_ext = ".o"
in_ext = ".c"
dep_ext = ".d"

# first scan dst for d and o pairs (both must exist) and all deps, any that dont have a source should be removed
for dst_path in Path(dst_dir).rglob("*" + out_ext):
	dst_abs_fragment = dst_path.relative_to(dst_dir_path)
	src_path_file = src_dir_path / dst_abs_fragment.with_suffix(in_ext)
	if(not src_path_file.is_file()):
		dst_path.unlink()

for dst_path in Path(dst_dir).rglob("*" + dep_ext):
	dst_abs_fragment = dst_path.relative_to(dst_dir_path)
	src_path_file = src_dir_path / dst_abs_fragment.with_suffix(in_ext)
	if(not src_path_file.is_file()):
		dst_path.unlink()

#for ext in extension_patterns:

src_tuples = []
processes = []
#could parallelise this more easily by constructing a list while also kicking off dep creation where necessary
for src_path in Path(src_dir).rglob("*" + in_ext):
	src_abs_fragment = src_path.relative_to(src_dir_path)
	dst_path_obj = dst_dir_path / src_abs_fragment.with_suffix(out_ext)
	dst_path_obj.parents[0].mkdir(parents=True, exist_ok=True)

	src_mtime = src_path.stat().st_mtime

	# compile if dst doesn't exist src has changed since it was compiled
	compile = not dst_path_obj.is_file() or dst_path_obj.stat().st_mtime < src_mtime

	dst_path_dep = dst_dir_path / src_abs_fragment.with_suffix(dep_ext)
	# if o-file parent directories exist, so must d-file's

	# make sure no dependencies have been removed, compile if they have
	dep_file_invalid = False
	if(not compile and dst_path_dep.is_file()):
		dependencies = dst_path_dep.read_text()
		local_dep_files = re.findall(src_dir+"/([^ ]*?).([hc])[ \n]", dependencies, re.M) ## re.M = multiline
		for ld_fragment, ld_ext in local_dep_files:
			src_dep = src_dir_path / (ld_fragment + "." + ld_ext)
			if(not src_dep.is_file()):
				compile = True

	# create the dependency list file if src has changed or dep doesnt exist
	if( compile or not dst_path_dep.is_file() or dst_path_dep.stat().st_mtime < src_mtime ):
		# print("create dep file")
		processes.append(Popen([compiler, str(src_path), "-MM", "-MF", str(dst_path_dep)] + arguments, universal_newlines=True, stdout=PIPE, stderr=PIPE))
		# check_for_errors(dep_out)

	src_tuples.append((src_path, compile, dst_path_dep, dst_path_obj))

flush_process_queue( processes, 0 )


for src_path, compile, dst_path_dep, dst_path_obj in src_tuples:

	# analyse deps, checking against map, need to do this even if compiling to record that we looked at these files (marked them)
	if(not compile):
		dependencies = dst_path_dep.read_text()
		local_dep_files = re.findall(src_dir+"/([^ ]*?)[ \n]", dependencies, re.M) ## re.M = multiline
		for ld_filename in local_dep_files:
			src_dep = src_dir_path / ld_filename

			if ld_filename in dependency_map:
				dep_mtime = dependency_map[ld_filename]
				# print("dep changed: " + str(dep_changed))
			else:
				if(not src_dep.is_file()):
					print("DERP NEEED TO REBUILD DEP LIST FILE WHEN DEPS MAY HAVE CHANGED (scan dep changes to see if deps are invalid)")
					# above should never get hit!
					sys.exit("error:0:0:error dependency missing for: "+ str(src_path) + " : " + str(src_dep))
					 # + str(local_dep_files)
				dep_mtime = src_dep.stat().st_mtime
				dependency_map[ld_filename] = dep_mtime

			# if we're here (analysing dependencies) the o file must exist and we must have found its mod time
			compile = compile or dst_path_obj.stat().st_mtime < dep_mtime

	if( compile ):
		processes.append(Popen([compiler, str(src_path), "-o", str(dst_path_obj), "-c"] + arguments, universal_newlines=True, stdout=PIPE, stderr=PIPE))
		# print("compile")
		# cmp_out = subprocess.run(["gcc", str(src_path), "-o", str(dst_path_o), "-c"] + arguments, capture_output=True, universal_newlines=True).stderr
		# check_for_errors(cmp_out)

flush_process_queue( processes, 0 )



for line in reversed(warnings_and_misc):
	print(line)

for line in reversed(errors):
	print(line)

if( len(warnings_and_misc) > 0 ):
	print(str(len(warnings_and_misc)) + " WARNINGS")

if( len(errors) > 0 ):
	print("ERROR COUNT: " + str(len(errors)))
	sys.exit(-1)
else:
	print("NO ERRORS")
	sys.exit(0)