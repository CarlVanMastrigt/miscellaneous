

if [ $# -lt 4 ];then
	echo "ERROR, must specify source_folder, intermediary_folder, destinatiopn_folder and destination_exe_name as arguments"
	exit -1
fi

source=$1
intermediary=$2
destination=$3
app_file=$4

shift 4

c_compiler=clang
# c_compiler=gcc

python3 build_tools/recompile_shaders.py $source $destination

# still need something to build and copy resources! (both base and )

# build objects from sorce
# python3 build_tools/recompile_source.py gcc $source $intermediary -g -std=c2x -msse4.1 -I/usr/include/freetype2 -I./$source/solipsix -I./$source $@
python3 build_tools/recompile_source.py $c_compiler $source $intermediary -g -std=c2x -msse4.1 -I/usr/include/freetype2 -I./$source/solipsix -I./$source -I./$source/external_includes $@
# -I/usr/include/wx-3.2/wx/x11/nanox/


if [ $? == 0 ];then
	# if no errors (nonzero return code from building objects) then build the executable
	# python3 build_tools/compile_program.py gcc $intermediary $destination/$app_file -g -lfreetype -lvulkan -lpthread -lSDL2 -lm -lc $@
	python3 build_tools/compile_program.py $c_compiler $intermediary $destination/$app_file -g -lfreetype -lharfbuzz -lfribidi -lvulkan -lpthread -lSDL3 -lm -lc $@
	#-lX11
	#-licuuc
	echo "built: $destination/$app_file"
fi

